public class main {
    public static void main(String[] args) {
        // Asıl JavaFX uygulamamızı buradan gizlice tetikliyoruz
        LoginApp.main(args);
    }
}